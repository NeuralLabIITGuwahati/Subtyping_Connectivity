clc
close all
clear all
tic
%% Subject age gender
nHC = 78;% single scanner
nPD = 131;
cd 'E:\PPMI_results\Single_scanner\3_Seg_Reg_Sm_PPMI\5_BICA'%E:\PPMI_results\Single_scanner\Smoothed_scans\GIFT';%'E:\PPMI_results\Single_scanner\BICA';
[num, txt, raw]  = xlsread('master_PPMI_BICA_16112022.xlsx','Single_scanner_TrioTim'); % excel sheet with all subjects Age, Gender, Diagnosis data
txt = txt(2:end,:);
Gender = num(:,4); % Male: 1 & Female : 0
Age = num(:,5);
Diag= num(:,3); % HC: 2 & PD: 1
HCnames = txt(find(Diag == 2),1); % Names of HC 
HC_sl  =  find(Diag==2); % Sl num of HC in the excel as well as SBM matrix
PDnames = txt(find(Diag == 1),1); % Names of PD
PD_sl  =  find(Diag==1); % Sl num of PD in the excel as well as SBM matrix
Males = find(num(:,4) ==1); % Sl no of males in the entire dataset
Females = find(num(:,4) ==0); % Sl no of females in the entire dataset
Age_HC  = Age(1:nHC);
Age_PD = Age(nHC+1:end);
sex_HC = Gender(1:nHC);
sex_PD = Gender(nHC+1:end);
load('E:\PPMI_results\Single_scanner\3_Seg_Reg_Sm_PPMI\4_SBM\SBM_Subject.mat')%;('PPMI_SBMSubject.mat')
%% After using GIFT on 386 subjects (168 HC and 218 PD patients together) we got the SBM__group_loading_coeff_.nii in the output directory
grp_load_coeff = icatb_loadData(char('E:\PPMI_results\Single_scanner\3_Seg_Reg_Sm_PPMI\5_BICA\SBM__group_loading_coeff_.nii')); % Loading matrix 250*30
load_mat = grp_load_coeff;
mean_loadings = [mean(load_mat(1:nHC,:),1); mean(load_mat(nHC+1:end,:),1)];

for i = 1:size(grp_load_coeff,2)
    % comparing the loading coeff of HC and PD for each of the 30 components
    [h(i) p(i) ci statistics] = ttest2(load_mat(Diag==2,i),load_mat(Diag==1,i)); % by default ttest 2 tests 2 sample t test at 5% significance level 
    % h = 1 implies the data in x and y comes from populations with unequal    
end
p = p'; 
sig_comp_ttest = find(h==1);
%% Components with significant grp diff  - FDR test
[h_fdr, crit_p_fdr, adj_ci_cvrg, adj_p_fdr]=fdr_bh(p); % h_fdr is a logical binary vector. 
sig_comp_fdr = find(h_fdr==1);  % significant components
[sorted_sig_P, idx_P] = sort(p(sig_comp_fdr)); % Arranging p values in increasing order. Smallest p is more significant. So top 2 significant components are the ones with least  p values.
%% Cohen's d test and top two components
% effect sizes as small (d = 0.2), medium (d = 0.5), and large (d = 0.8) 
sig_load_mat = load_mat(:,sig_comp_ttest);
for i = 1: size(grp_load_coeff,2)
     mean_HC(i) = mean(load_mat(HC_sl,i),1);  std_HC (i) = std(load_mat(HC_sl,i)); 
    mean_PD(i) = mean(load_mat(PD_sl,i),1);  std_PD (i) = std(load_mat(PD_sl,i));
    numerator(i) = mean_HC(i) - mean_PD(i);
    denominator(i) = sqrt((((numel(HC_sl)-1)*(std_HC(i).^2)) + ((numel(PD_sl)-1)*(std_PD(i).^2)))/(numel(HC_sl)+numel(PD_sl)-2));
    d_Cohen(i) = abs(numerator(i)/denominator(i)); % Cohen's d test is applicable for sample size < 20
  end
% Hedges's g test
 Hedges_g = d_Cohen *(1-(3/(4*(numel(HC_sl)+numel(PD_sl))-9))); % Hedges's g test is applicable for sample size >20. It's correction of Cohens's d test.
[Hedge_Effect_size, idx_effect] =  sort(Hedges_g, 'descend');
ss = [19,26]; % Manually looked for loading coeff of Inferior, Middle & Superior Frontal & Temporal Gyrus
two_sig_comp = load_mat(:,ss); % for one scanner
mean_loadings = [mean(load_mat(1:nHC,:),1); mean(load_mat(nHC+1:end,:),1)];
%% N-BiC  Thresholding method from PD subjects only
two_sig_comp_PD = two_sig_comp(PD_sl,:);
mean_of_comp = mean(two_sig_comp_PD,1);
%subgrp 1: from comp 1 only
 if mean_of_comp(1) > 0
        idx_1 = find(two_sig_comp_PD(:,1) >= mean_of_comp(1));
else
        idx_1  = find(two_sig_comp_PD(:,1) < mean_of_comp(1));
end
% subgrp2: from comp 2 only
if mean_of_comp(2) > 0
        idx_2 = find(two_sig_comp_PD(:,2) >= mean_of_comp(2));
else
        idx_2  = find(two_sig_comp_PD(:,2) < mean_of_comp(2));
end
 %% Subgroup specific subjects from PD subjects only
 Grp_AB_idx = intersect(idx_1, idx_2);        % index common to both A and B
 Grp_AB_names = PDnames(Grp_AB_idx);     % names of subjects common to both A & B
 
 Grp_A_idx = setdiff(idx_1,Grp_AB_idx);            % exclusively subgroup  A subjects
Grp_A_names = PDnames(Grp_A_idx);

 Grp_B_idx = setdiff(idx_2,Grp_AB_idx);         % exclusively subgroup B subjects
 Grp_B_names = PDnames(Grp_B_idx); 
%% Females and males count in each subgroup
 F_A = find(Gender(nHC+Grp_A_idx)==0);
M_A = find(Gender(nHC+Grp_A_idx)==1);
 F_B = find(Gender(nHC+Grp_B_idx)==0);
M_B = find(Gender(nHC+Grp_B_idx)==1);
 F_AB = find(Gender(nHC+Grp_AB_idx)==0);
M_AB = find(Gender(nHC+Grp_AB_idx)==1);

 %% ANOVA on the loadings of specific subgroups from BICA
PD_loadings = load_mat(PD_sl,:);
j = ss; 
group= repelem([{'A'}, {'B'}, {'AB'}], [size(Grp_A_idx,1), size(Grp_B_idx,1), size(Grp_AB_idx,1)]);
 for i = 1:2
    loading_A(:,i) = PD_loadings(Grp_A_idx,j(i));
    loading_B(:,i) = PD_loadings(Grp_B_idx,j(i));
    loading_AB(:,i) = PD_loadings(Grp_AB_idx,j(i));
    A = loading_A(:,i);
    B = loading_B(:,i);
    AB = loading_AB(:,i);
    y_loading =[A' B' AB']; % concatenated loading coefficients of all subgroups
    [p_anova_load,table_load, stats_load] = anova1(y_loading,group);
    xticklabels({'A','B','AB'})
    xlabel('Subgroups')
    ylabel('Loadings')
 if p_anova_load < 0.05
     display('There is a significant difference between the subgroups')
 else
     display ('NO significant difference between the subgroups')
 end
    p_anova_loadng(i) = p_anova_load;
 end
 toc