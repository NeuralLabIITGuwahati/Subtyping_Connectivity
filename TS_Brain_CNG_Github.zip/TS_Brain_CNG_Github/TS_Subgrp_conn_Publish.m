%% 1. Load File
tic
% cd 'C:\Users\TestPC\Desktop\Conn_PPMI'
load('Grp_A_idx.mat'); % obtained from TS_BICA_PPMI.m
load('Grp_A_names.mat'); % obtained from TS_BICA_PPMI.m
load('Grp_B_idx.mat'); % obtained from TS_BICA_PPMI.m
load('Grp_B_names.mat'); % obtained from TS_BICA_PPMI.m
load('Grp_AB_idx.mat'); % obtained from TS_BICA_PPMI.m
load('Grp_AB_names.mat'); % obtained from TS_BICA_PPMI.m
[num, txt, raw]  = xlsread('master_PPMI_BICA_publish.xlsx'); % excel sheet with all subjects Age, Gender, Diagnosis data
txt = txt(2:end,:);
Diag= num(:,3); % HC: 2 & PD: 1
% PDnames = txt(find(Diag == 1),1); % Names of PD
PD_sl  =  find(Diag==1); % Sl num of PD in the excel as well as SBM matrix
PD_Age = num(PD_sl,5); % 5th column has age values
PD_Gender = num(PD_sl,4);% Male: 1 & Female : 0
A_age = PD_Age(Grp_A_idx,:);
B_age = PD_Age(Grp_B_idx,:);
AB_age = PD_Age(Grp_AB_idx,:);
A_gender = PD_Gender(Grp_A_idx,:);
B_gender = PD_Gender(Grp_B_idx,:);
AB_gender = PD_Gender(Grp_AB_idx,:);

%% 2. Regional GM vol of 56 ROIs as per LPBA40 atlas

[n1,t1,r1] =  xlsread('PD_rGMV_PPMI.xlsx'); % 179 sub * 56 ROIs
PD_GM = n1;
sub_id = t1(2:end);

A_GM = PD_GM(Grp_A_idx,:);
B_GM = PD_GM(Grp_B_idx,:);
AB_GM = PD_GM(Grp_AB_idx,:);
A_X = [ones(size(A_age)) A_age A_gender A_age.*A_gender];
B_X = [ones(size(B_age)) B_age B_gender B_age.*B_gender];
AB_X = [ones(size(AB_age)) AB_age AB_gender AB_age.*AB_gender];

%% 3. Multiple linear Regression : Regressing out the effect of age, gender and their combined effect

cA_GM = TS_func_regression_conn(A_GM,A_X,A_age,A_gender);
cB_GM = TS_func_regression_conn(B_GM,B_X,B_age,B_gender);
cAB_GM = TS_func_regression_conn(AB_GM,AB_X,AB_age,AB_gender);

%% 4. Interregional Correlation Matrix- Pearson's Correlation (56*56 matrix) #sub < #regions

A_wtGM = corrcoef(cA_GM); 
save ('A_wt_corr_mat.txt', 'A_wtGM', '-ascii')

B_wtGM = corrcoef(cB_GM); 
save ('B_wt_corr_mat.txt', 'B_wtGM', '-ascii')

AB_wtGM = corrcoef(cAB_GM); 
save ('AB_wt_corr_mat.txt', 'AB_wtGM', '-ascii')

%% 5. Association matrix - Weighted undirected matrix
mat = 'A';
TS_func_association_mat_conn(A_wtGM,mat)
saveas(gcf, 'WU_A.png') % saved in above mentioned path

mat = 'B';
TS_func_association_mat_conn(B_wtGM,mat)
saveas(gcf, 'WU_B.png') % saved in above mentioned path

mat = 'AB';
TS_func_association_mat_conn(AB_wtGM,mat)
saveas(gcf, 'WU_AB.png') % saved in above mentioned path


%% 6. Network Connectivity
% Binarization for A based on sparsity Threshold based on Sanabria-Diaz et al., 2010 Surface area and cortical thickness descriptors reveal different attributes of the structural human brain networks
% Network Metric Calculation
% Sigma calculation for A with 1000 random networks per sparsity
[Sparsity, A_3D, deg_A, density_A, ~,eff_local_A, ~, ~, ~, BC_A, ~,~,~, mean_clust_coef_A, mean_lambda_A, mean_gamma_A, mean_sigma_A, mean_local_eff_A, avg_deg_A, clust_coef_A] = TS_func_nw_conn_metrics(A_wtGM);
[Sparsity, B_3D, deg_B, density_B, ~,eff_local_B, ~, ~, ~, BC_B, ~,~,~, mean_clust_coef_B, mean_lambda_B, mean_gamma_B, mean_sigma_B, mean_local_eff_B, avg_deg_B, clust_coef_B] = TS_func_nw_conn_metrics(B_wtGM);
[Sparsity, AB_3D, deg_AB, density_AB, ~, eff_local_AB, ~, ~, ~, BC_AB, ~,~,~, mean_clust_coef_AB, mean_lambda_AB, mean_gamma_AB, mean_sigma_AB, mean_local_eff_AB, avg_deg_AB, clust_coef_AB] = TS_func_nw_conn_metrics(AB_wtGM);

Sparsity= [0.55: 0.025 : 0.9];

%% 7. Plot after running all metric measurements for each subgroup (A, B and AB)

% Plot of threshold vs mean clust_coeff
nw_metric = 'Mean Clustering coefficient';
TS_func_plot_nw_metrics(mean(mean_clust_coef_A,1), mean(mean_clust_coef_B,1), mean(mean_clust_coef_AB,1), nw_metric)
saveas(gcf, 'A_B_AB_clust_coef.png') % saved in above mentioned path

% Plot of threshold vs mean local efficiency
nw_metric = 'Mean Local Efficiency';
TS_func_plot_nw_metrics(mean(eff_local_A,1), mean(eff_local_B,1),mean(eff_local_AB,1), nw_metric)
saveas(gcf, 'A_B_AB_localeff.png') % saved in above mentioned path

% Plot of  threshold vs Betweenness Centrality 
nw_metric = 'Mean Betweenness Centrality';
TS_func_plot_nw_metrics(mean(BC_A,1), mean(BC_B,1), mean(BC_AB,1), nw_metric)
saveas(gcf, 'A_B_AB_Betweenness_Centrality.png')

%%  8. Hubs at sparsity of 0.55 since network was constructed at 0.55  is a value with good density(0.45) and sparsity(0.55), also used in BrainNet

hubs_A = TS_func_hub_conn(deg_A,BC_A);
hubs_B = TS_func_hub_conn(deg_B,BC_B);
hubs_AB = TS_func_hub_conn(deg_AB,BC_AB);

%% 9. Binary undirected matrix figure at 1st level of sparsity (i.e.  0.55)

mat = 'A';
TS_func_adjacency_mat_conn(A_3D,mat)
saveas(gcf, 'BU_A_0pt55.png')

mat = 'B';
TS_func_adjacency_mat_conn(B_3D,mat)
saveas(gcf, 'BU_B_0pt55.png')

mat = 'AB';
TS_func_adjacency_mat_conn(AB_3D,mat)
saveas(gcf, 'BU_AB_0pt55.png')

%% 10. Permutation Test for group differences in subgroups for clustering coefficient 
nw_metric = 'Mean Clustering Coefficient';

mat1 = 'A'; 
mat2 = 'B';
TS_func_PermTest_CC(mean_clust_coef_A, mean_clust_coef_B, clust_coef_A, clust_coef_B, Sparsity, nw_metric, mat1, mat2)
% TS_func_PermTest_CC(mean_clust_coeff_A, mean_clust_coeff_B, clust_coef_A, clust_coef_B, Sparsity,nw_metric, mat1, mat2)
%legend({'Mean','Upperbound(95% CI)','Lowerbound(95% CI)','A vs  B'},'Location','north','Orientation','horizontal')
saveas(gcf, 'Grp_diff_AvsB_CC.png') % saved in above mentioned path

mat1 = 'A'; 
mat2 = 'AB';
TS_func_PermTest_CC(mean_clust_coef_A, mean_clust_coef_AB, clust_coef_A, clust_coef_AB, Sparsity, nw_metric, mat1, mat2)
% TS_func_PermTest_CC(mean_clust_coeff_A, mean_clust_coeff_B, clust_coef_A, clust_coef_B, Sparsity,nw_metric, mat1, mat2)
saveas(gcf, 'Grp_diff_AvsAB_CC.png') % saved in above mentioned path

mat1 = 'B'; 
mat2 = 'AB';
TS_func_PermTest_CC(mean_clust_coef_B, mean_clust_coef_AB, clust_coef_B, clust_coef_AB, Sparsity, nw_metric, mat1, mat2)
% TS_func_PermTest_CC(mean_clust_coeff_A, mean_clust_coeff_B, clust_coef_A, clust_coef_B, Sparsity,nw_metric, mat1, mat2)
saveas(gcf, 'Grp_diff_BvsAB_CC.png') % saved in above mentioned path

%% Permutation Test for group differences in subgroups for local efficiency
nw_metric = 'Mean Local Efficency';

mat1 = 'A'; mat2 = 'B';
obs_diff = mean(eff_local_A,1) - mean(eff_local_B,1);% dim: 1*11   
TS_func_permutation_test(eff_local_A, eff_local_B,obs_diff,Sparsity, nw_metric, mat1, mat2)
% legend({'Mean','Upperbound(95% CI)','Lowerbound(95% CI)','A vs B'},'Location','north','Orientation','horizontal')
saveas(gcf, 'Grp_diff_AvsB_loceff.png') % saved in above mentioned path

mat1 = 'A'; mat2 = 'AB';
obs_diff = mean(eff_local_A,1) - mean(eff_local_AB,1);% dim: 1*11   
TS_func_permutation_test(eff_local_A, eff_local_AB,obs_diff,Sparsity, nw_metric, mat1, mat2)
saveas(gcf, 'Grp_diff_AvsAB_loceff.png') % saved in above mentioned path

mat1 = 'B'; mat2 = 'AB';
obs_diff = mean(eff_local_B,1) - mean(eff_local_AB,1);% dim: 1*11   
TS_func_permutation_test(eff_local_B, eff_local_AB,obs_diff,Sparsity, nw_metric, mat1, mat2)
saveas(gcf, 'Grp_diff_BvsAB_loceff.png') % saved in above mentioned path

%% Permutation Test for group differences in subgroups for Betweenness centrality 
nw_metric = 'Betweenness Centrality';

mat1 = 'A'; mat2 = 'B';
obs_diff = mean(BC_A,1)- mean(BC_B,1);% dim: 1*11    
TS_func_permutation_test(BC_A, BC_B,obs_diff,Sparsity, nw_metric, mat1, mat2)
ylim([-55 50])
% legend({'Mean','Upperbound(95% CI)','Lowerbound(95% CI)','B vs A'},'Location','north','Orientation','horizontal')
saveas(gcf, 'Grp_diff_AvsB_BC.png') % saved in above mentioned path

mat1 = 'A'; mat2 = 'AB';
obs_diff = mean(BC_A,1)- mean(BC_AB,1);% dim: 1*11    
TS_func_permutation_test(BC_A, BC_AB,obs_diff,Sparsity, nw_metric, mat1, mat2)
ylim([-55 50])
saveas(gcf, 'Grp_diff_AvsAB_BC.png') % saved in above mentioned path

mat1 = 'B'; mat2 = 'AB';
obs_diff = mean(BC_B,1)- mean(BC_AB,1);% dim: 1*11    
TS_func_permutation_test(BC_B, BC_AB,obs_diff,Sparsity, nw_metric, mat1, mat2)
ylim([-55 50])
saveas(gcf, 'Grp_diff_BvsAB_BC.png') % saved in above mentioned path


%% End
toc